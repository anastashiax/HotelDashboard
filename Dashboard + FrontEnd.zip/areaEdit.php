<!DOCTYPE html>
<?php
ob_start();
session_start();
if(!isset($_SESSION['emailUser'])) {
    header("location:login.php");
}
?>

<?php include "header.php";?>

<div class="container-fluid">
    <div class="card shadow mb-4">

<?php
    include "includes/config.php";

    if(isset($_POST['Edit'])) {
        if (isset($_REQUEST['inputAreaID'])) {
            $areaID = $_REQUEST['inputAreaID'];
        }

        if (!empty($areaID)) {
            $areaID = $_REQUEST ['inputAreaID'];
        }

        else {
            ?> <h1>Anda harus mengisi data</h1> <?php
            die ("Anda harus memasukkan datanya");
        }

        $areaNama = $_POST['inputAreaNama'];
        $areaWilayah = $_POST['inputAreaWilayah'];
        $areaKeterangan = $_POST['inputAreaKeterangan'];
        $kodeProvinsi = $_POST['kodeProvinsi'];

    mysqli_query($connection, "Update a_travel.Area set areaNama = '$areaNama', areaWilayah = '$areaWilayah', 
                            areaKeterangan = '$areaKeterangan', provinsiID = '$kodeProvinsi'
                            WHERE areaID = '$areaID'");
    header("location:area.php");
    }

    $dataArea = mysqli_query($connection, "SELECT * FROM a_travel.area");
    $dataProvinsi = mysqli_query($connection, "SELECT * FROM a_travel.provinsi");

    // Untuk menampilkan data pada Form Edit
    $areaID = $_GET["ubah"];
    $areaEdit = mysqli_query($connection, "SELECT * FROM a_travel.area WHERE areaID = '$areaID'");
    $rowEdit = mysqli_fetch_array($areaEdit);
    $editArea = mysqli_query($connection, "SELECT * FROM a_travel.area, a_travel.provinsi WHERE areaID = '$areaID'
                                 AND area.areaID = provinsi.provinsiID");
    $rowEdit2 = mysqli_fetch_array($editArea);
    $editProvinsi = mysqli_query($connection, "SELECT * FROM a_travel.provinsi, a_travel.area WHERE areaID = '$areaID'
                                 AND provinsi.provinsiID = area.provinsiID");
    $rowEdit3 = mysqli_fetch_array($editProvinsi);

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Database Area</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
</head>

<div class="row">
    <div class="col-sm-1">
    </div>
    <div class="col-sm-10">
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <h1 class="display-4">Input Area</h1>
                <h2>Hasil Entri data pada Tabel Area</h2>
            </div>
        </div> <!-- penutup jumbtron -->

        <form method="POST">
            <div class="form-group row">
                <label for="areaID" class="col-sm-2 col-form-label">Area ID</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="areaID" name="inputAreaID" value ="<?php echo $rowEdit["areaID"]?>" placeholder="Area ID (max. 4 characters)" maxlength="4">
                </div>
            </div>

            <div class="form-group row">
                <label for="areaNama" class="col-sm-2 col-form-label">Nama Area</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="areaNama" name="inputAreaNama" value ="<?php echo $rowEdit["areaNama"]?>" placeholder="Nama Area (max. 35 characters)" maxlength="35">
                </div>
            </div>

            <div class="form-group row">
                <label for="areaWilayah" class="col-sm-2 col-form-label">Nama Wilayah</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="areaWilayah" name="inputAreaWilayah" value ="<?php echo $rowEdit["areaWilayah"]?>" placeholder="Nama Wilayah (max. 35 characters)" maxlength="35">
                </div>
            </div>

            <div class="form-group row">
                <label for="areaKeterangan" class="col-sm-2 col-form-label">Keterangan</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="areaKeterangan" name="inputAreaKeterangan" value ="<?php echo $rowEdit["areaKeterangan"]?>" placeholder="Keterangan (max. 225 characters)" maxlength="225">
                </div>
            </div>

            <div class="form-group row">
                <label for="areaKeterangan" class="col-sm-2 col-form-label">Kode Provinsi</label>
                <div class="col-sm-10">
                    <select id="kodeProvinsi" name="kodeProvinsi" class="form-control">
                        <option value="<?php echo $rowEdit["provinsiID"]?>"><?php echo
                            $rowEdit['provinsiID']?> <?php echo $rowEdit3['provinsiNama']?></option>
                        <?php
                            while($row = mysqli_fetch_array($dataProvinsi))
                        { ?>
                            <option value="<?php echo $row["provinsiID"]?>">
                                <?php echo $row["provinsiID"]?>
                                <?php echo $row["provinsiNama"]?>
                            </option>
                        <?php }?>
                </div>
                </select>
            </div>
    </div>

            <div class="form-group row">
                <div class="col-sm-2"></label>
                </div>
                <div class="col-sm-10">
                    <input type="submit" class="btn btn-primary" value="Edit" name="Edit">
                    <input type="reset" class="btn btn-secondary" value="Cancel" name="'Cancel">
                </div>
            </div>
        </form>
    </div>

    <div class="col-sm-1">
    </div>
</div>

<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <h1 class="display-4">Daftar Area</h1>
                <h2>Hasil Output dari Tabel Area</h2>
            </div>

        </div> <!-- penutup jumbtron -->
        <form method="POST">
            <div class="form-group row mb-2">
                <label for="search" class="col-sm-3">Pencarian Area</label>
                <div class="col-sm-6">
                    <input type="text" name="search" class="form-control" id="search" value="<?php if(isset($_POST['search'])) {echo $_POST['search'];}?>" placeholder="Cari ID/Nama/Provinsi ID">
                </div>
                <input type="submit" name="kirim" class="col-sm-1 btn btn-primary" value="Search">
            </div>
        </form>

        <table class="table table-hover table-danger">
            <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>ID Area</th>
                <th>Nama Area</th>
                <th>Nama Wilayah</th>
                <th>Keterangan</th>
                <th>ID Provinsi</th>
                <th colspan="2" style="text-align: center">Action</th>
            </tr>
            </thead>

            <tbody>
            <?php
            if (isset($_POST["kirim"])) {
                $search = $_POST['search'];
                $query = mysqli_query($connection, "select * from a_travel.Area
                    where areaID like '%".$search."%'
                        or areaNama like '%".$search."%'
                        or provinsiID like '%".$search."%'");
            }
            else {
                $query = mysqli_query($connection, "select * from a_travel.Area");
            }
            $nomor =1;
            while ($row = mysqli_fetch_array($query)) {
                ?>
                <tr>
                    <td><?php echo $nomor;?></td>
                    <td><?php echo $row['areaID'];?></td>
                    <td><?php echo $row['areaNama'];?></td>
                    <td><?php echo $row['areaWilayah'];?></td>
                    <td><?php echo $row['areaKeterangan'];?></td>
                    <td><?php echo $row['provinsiID'];?></td>
                    <!-- Untuk icon Edit dan Delete -->
                    <td>
                        <a href="areaEdit.php?ubah=<?php echo $row["areaID"]?>"
                           class="btn btn-success btn-sm" title="Edit Data">
                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                            </svg>
                        </a>
                    </td>
                    <td>
                        <a href="areaHapus.php?hapus=<?php echo $row["areaID"]?>"
                           class="btn btn-danger btn-sm" title="Delete Data">
                            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash2-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                <path d="M2.037 3.225l1.684 10.104A2 2 0 0 0 5.694 15h4.612a2 2 0 0 0 1.973-1.671l1.684-10.104C13.627 4.224 11.085 5 8 5c-3.086 0-5.627-.776-5.963-1.775z"/>
                                <path fill-rule="evenodd" d="M12.9 3c-.18-.14-.497-.307-.974-.466C10.967 2.214 9.58 2 8 2s-2.968.215-3.926.534c-.477.16-.795.327-.975.466.18.14.498.307.975.466C5.032 3.786 6.42 4 8 4s2.967-.215 3.926-.534c.477-.16.795-.327.975-.466zM8 5c3.314 0 6-.895 6-2s-2.686-2-6-2-6 .895-6 2 2.686 2 6 2z"/>
                            </svg>
                        </a>
                    </td>
                    <!-- Akhir icon Edit dan Delete -->
                </tr>
                <?php $nomor = $nomor + 1;?>
            <?php }
            ?>
            </tbody>
        </table>
    </div>
</div>
<div class="col-sm-1"></div>
</div>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#kodeProvinsi').select2( {
            allowClear: true,
            placeholder: "Pilih Provinsi ID"
        });
    });
</script>
</div>
<?php include "footer.php";?>
<?php
    mysqli_close($connection);
    ob_end_flush();
?>
</html>