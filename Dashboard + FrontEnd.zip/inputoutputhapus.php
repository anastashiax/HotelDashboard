<?php
 include "includes/config.php";
 if(isset($_GET['hapus']))
 {
  $kodekategori = $_GET["hapus"];
  mysqli_query($connection, "DELETE FROM kategori 
   where kategoriID = '$kodekategori'");
  echo "<script>alert('Data Berhasil di Hapus');
   document.location='inputoutput.php'</script>";
 }
?>