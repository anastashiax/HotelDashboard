<!doctype html>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<?php
    include "include/config.php";
    if(isset($_POST['view'])) {
        header("location:index.php");
    }
    $jumlahtampilan = 4;
    $halaman = (isset($_GET['page']))? $_GET['page'] : 1;
    $mulaitampilan = ($halaman - 1) * $jumlahtampilan;

    $foto = mysqli_query($connection, "SELECT * FROM fotomaldive limit $mulaitampilan, $jumlahtampilan");

    $query = mysqli_query($connection, "SELECT * FROM fotomaldive");
    $jumlahrecord = mysqli_num_rows($query);
    $jumlahpage = ceil($jumlahrecord/$jumlahtampilan);
?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Maldives' Gallery</title>
    <style>
        body {
          background-color: pink;
        }
    </style>
  </head>
  <body>
       <!-- MEMBUAT MENU -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="index.php">
      <img src="images/falconpng.png" style="width: 60px">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Gallery
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="fiji.php">Fiji</a>
            <a class="dropdown-item" href="maldives.php">Maldives</a>
            <a class="dropdown-item" href="tahiti.php">Tahiti</a>
            <a class="dropdown-item" href="france.php">France</a>
            <a class="dropdown-item" href="turkey.php">Turkey</a>
            <a class="dropdown-item" href="thailand.php">Thailand</a>
        </div>
      </li>
  
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
<!-- AKHIR MENU -->
<br><br><br>
<div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 style= "font-family: 'Abril Fatface', cursive" class="display-4">Maldive's Gallery</h1>
        </div>
</div>
<!-- GALERI -->
<div class="container">
<div class="row">
    <?php while ($row = mysqli_fetch_array($foto)) { ?>
    <div class="col-sm-10">
    <figure class="figure">
    <img src="fotomaldives/<?php echo $row['fotofile'] ?>" class="figure-img img-fluid rounded" alt="Foto Tidak Ada" width="500px" height="250px">
    <h4 style= "font-family: 'Abril Fatface', cursive"><?php echo $row['fotonama'] ?></h4>
    <p style="text-align: justify;"><?php echo $row['fotoket'] ?></p>
    </figure>
    </div>
    <?php } ?>
</div>
</div>
<!-- END GALERI -->

<!-- PAGINATION -->
<div class="container"></div>
<div class="row"></div>
<div class="col-sm-10" style="margin: auto;">
<nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item">
      <a class="page-link" href="?page=<?php $nomorhal=1; echo $nomorhal ?>" aria-label="Previous">
        <span aria-hidden="true">&laquo;</span>
        <span class="sr-only">Previous</span>
      </a>
    </li>
    <?php 
      for($nomorhal = 1; $nomorhal<=$jumlahpage; $nomorhal++)
      { ?>
    <li class="page-item">
      <?php 
      if($nomorhal!=$halaman)
      { ?>
        <a class="page-link" href="?page=<?php echo $nomorhal ?>"><?php echo $nomorhal ?></a>
        <?php }
      else { ?>
        <a class="page-link" href="?page=<?php echo $nomorhal ?>"><?php echo $nomorhal ?></a>
      <?php } ?>
    </li>
    <?php } ?>
    <li class="page-item">
      <a class="page-link" href="?page=<?php echo $nomorhal-1 ?>" aria-label="Next">
        <span aria-hidden="true">&raquo;</span>
        <span class="sr-only">Next</span>
      </a>
    </li>
  </ul>
</nav>
</div>
</div>
</div>
<style>
.testimonial {
    background: #f7f7f7;
}

.testimonial .content {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
}

.testimonial .content .testimonialBox {
    max-width: calc(40% - 30px);
    padding: 60px 40px;
    margin: 20px;
    background : red;
}

.testimonial .content .testimonialBox p {
    color :#fff;
    font-style: italic;
    font-size: 16px;
    font-weight: 2;
}

.testimonial .content .testimonialBox h3 {
    margin-top: 40px;
    text-align: end;
    color: #fff;
    font-weight: 600;
    font-size: 20px;
    line-height: 1em;
}

.testimonial .content .testimonialBox h3 span {
    font-size: 14px;
    font-weight: 400;
}</style>
<div class="jumbotron jumbotron-fluid text-center">
      <div class="container">
        <section class="testimonial" id="testimonial">
        <div class="heading">
        <h1 style= "font-family: 'Abril Fatface', cursive">Reviews</h1>
    
        </div>
        <div class="content">
            <div class="testimonialBox">
                <p>Everything was absolutely amazing! The villa, staff, surroundings. We extend our stay for another 3 weeks. Thank you very much for your great and professional service! I really enjoy outside bath, delicious breakfast, quiet and privacy in own pool.
                </p>
                <h3>Anastasia Aurelia<br><span>Royal School Of Music. London, UK</span></h3>
            </div>
            <div class="testimonialBox">
                <p>
                The room and view was very nice. We love the sound environment and also the breakfast was amazing!
                </p>
                <h3>Daniela Drache<br><span>Stanford University. California</span></h3>
            </div>
            <div class="testimonialBox">
                <p>
                Absolutely amazing accomodations!! The best breakfast of any place we stayed during our vacation. Joe and Christopher are fantastic hosts. Will definitely stay here when we return to Nova Scotia!
                </p>
                <h3>Joan Kennedy<br><span>Harvard University. Cambridge, Massachusetts.</span></h3>
            </div>
            <div class="testimonialBox">
                <p>
                Very warm welcome from the owners, the house and the room we got were beautiful and clean. The house is located on top of a hill, the view in the morning is amazing! The breakfast was great with fresh ingredients.
                </p>
                <h3>Thamara Hoefkens, Ph.D<br><span>Massachusetts Institute of Technology. Cambridge</span></h3>
            </div>
        </div>
    </section>        <br>
    <a class="btn btn-danger btn-lg" target="_blank" href="/adminanas/test2/index.html" role="button" >MORE</a>
      </div>
  </div>
<!-- END PAGINATION -->
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>