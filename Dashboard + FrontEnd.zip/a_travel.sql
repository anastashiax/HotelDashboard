-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2020 at 03:52 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a_travel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` char(4) NOT NULL,
  `adminNama` char(30) NOT NULL,
  `adminEmail` varchar(60) NOT NULL,
  `adminPassword` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `adminNama`, `adminEmail`, `adminPassword`) VALUES
('1', 'Nova', 'Nova@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e'),
('2', 'Anaz', 'aurelanas@gmail.com', 'c279d27396354034218847669660c7d7');

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE `area` (
  `areaID` char(4) NOT NULL,
  `areaNama` char(35) NOT NULL,
  `areaWilayah` char(35) NOT NULL,
  `areaKeterangan` varchar(255) NOT NULL,
  `provinsiID` char(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`areaID`, `areaNama`, `areaWilayah`, `areaKeterangan`, `provinsiID`) VALUES
('AA01', 'Antarctica', 'South Pole', 'land area is covered by ice. Though not itself a country, areas are claimed by a number of countries.', '01'),
('ARE1', 'Canada', 'North America', 'Its ten provinces and three territories extend from the Atlantic to the Pacific and northward into the Arctic Ocean, covering 9.98 million square kilometres (3.85 million square miles), making it the world\'s second-largest country by total area. ', '02'),
('ARE3', 'Norway', 'Northern Europe', 'Kingdom of Norway, including Svalbard and Jan Mayen, but excluding Bouvet Island and the Antarctic territorial claims of Queen Maud Land and Peter I Island.', '03'),
('ARE4', 'Russia', 'Российская Федерация', 'The largest country in the world by land area. About 146.7 million people live in Russia according to the 2019 census. The capital city of Russia is Moscow.', '04'),
('ARE5', 'China', 'East Asia', 'China also has one of the world\'s oldest writing systems (and the oldest in use today). China has been the source of many major inventions.', '05'),
('ARE6', 'Australia', 'Sydney, Oceania', 'The sixth biggest country in the world by land area, and is part of the Oceanic and Australasian regions. Australia, New Zealand, New Guinea and other islands on the Australian tectonic plate are together called Australasia.', '06');

-- --------------------------------------------------------

--
-- Table structure for table `beritawisata`
--

CREATE TABLE `beritawisata` (
  `beritaID` char(5) NOT NULL,
  `beritaisi` varchar(2000) NOT NULL,
  `destinasiID` char(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `beritawisata`
--

INSERT INTO `beritawisata` (`beritaID`, `beritaisi`, `destinasiID`) VALUES
('NWS1', 'Scientists claim to have built a quantum computer that is able to perform certain computations nearly 100 trillion times faster than the world’s most advanced supercomputer, representing the first milestone in the country’s efforts to develop the technology.\r\n\r\nThe researchers have built a quantum computer prototype that is able to detect up to 76 photons through Gaussian boson sampling, a standard simulation algorithm, the state-run Xinhua news agency said, citing research published in Science magazine. That’s exponentially faster than existing supercomputers.', 'DES1'),
('NWS2', 'The breakthrough represents a quantum computational advantage, also known as quantum supremacy, in which no traditional computer can perform the same task in a reasonable amount of time and is unlikely to be overturned by algorithmic or hardware improvements, according to the research.', 'DES2'),
('NWS3', 'Though the decor followed a modern aesthetic, the room still kept a cozy vibe. I had concerns that it was going to be like staying in a gallery with a bed, but the 386-square-foot room was bright and inviting. The colors in the room were very neutral, but pops of art on the wall kept it all interesting. The lighting in the bathroom made for incredible selfies, and I was obsessed with the brass fixtures.', 'DES3'),
('NWS4', 'FDA issues emergency use authorization for Pfizer/BioNTech Covid-19 vaccine: a medical product gets special authorization by the FDA to be used during an emergency -- but it is short of a full approval. Pfizer would have to file a separate application for its vaccine to be fully licensed by the FDA.\r\n', 'DES4'),
('NWS5', 'Whanganui, New Zealand (CNN)As a child in the 1970s, Gerrard Albert played on the mud flats at the mouth of New Zealand\'s Whanganui River where raw sewage from the nearby town spilled into the estuary and out to the ocean.', 'DES5');

-- --------------------------------------------------------

--
-- Table structure for table `destinasi`
--

CREATE TABLE `destinasi` (
  `destinasiID` char(4) NOT NULL,
  `destinasiNama` char(35) NOT NULL,
  `destinasiAlamat` char(35) NOT NULL,
  `kategoriID` char(4) NOT NULL,
  `areaID` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `destinasi`
--

INSERT INTO `destinasi` (`destinasiID`, `destinasiNama`, `destinasiAlamat`, `kategoriID`, `areaID`) VALUES
('DES1', 'Fiji', 'Taveuni\'s diverse coral reefs', 'KAT1', 'ARE1'),
('DES2', 'Maldives', ' Pearlescent sands, Towering palm', 'KAT2', 'ARE2'),
('DES3', 'Tahiti', 'La Plage de Maui', 'KAT3', 'ARE3'),
('DES4', 'France', 'Loire Valley', 'KAT4', 'ARE4'),
('DES5', 'Turkey', 'Mediterranean Sea coasts', 'KAT5', 'ARE5'),
('DES6', 'Thailand', 'Bangkok', 'KAT6', 'ARE6');

-- --------------------------------------------------------

--
-- Table structure for table `fotodestinasi`
--

CREATE TABLE `fotodestinasi` (
  `fotoID` char(5) NOT NULL,
  `fotoNama` char(60) NOT NULL,
  `destinasiID` char(4) NOT NULL,
  `fotoFile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fotodestinasi`
--

INSERT INTO `fotodestinasi` (`fotoID`, `fotoNama`, `destinasiID`, `fotoFile`) VALUES
('FOT1', 'Frame1', 'DES1', '4.jpg'),
('FOT2', 'Frame2', 'DES2', '1.jpg'),
('FOT3', 'Frame3', 'DES3', '5.jpg'),
('FOT4', 'Frame4', 'DES4', '6.jpg'),
('FOT5', 'Frame5', 'DES5', '3.jpg'),
('FOT6', 'Frame6', 'DES6', '2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fotofiji`
--

CREATE TABLE `fotofiji` (
  `fotoID` char(4) NOT NULL,
  `fotonama` varchar(60) NOT NULL,
  `fotoket` text NOT NULL,
  `fotofile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fotofiji`
--

INSERT INTO `fotofiji` (`fotoID`, `fotonama`, `fotoket`, `fotofile`) VALUES
('F001', 'Hotel Tivoli', 'Painters and art world royalty Brice and Helen Marden have lived in Tivoli (about two hours north of New York City) for 12 years, and when their local hangout—a restaurant in the Madalin Hotel—was shuttered a couple of years ago, Brice says he was “so depressed at driving by this empty, dead building” that they bought it.', 'hotel tivoli.jpg'),
('F002', 'The Albatroz', 'Although once a whitewashed fishing village, Cascais long ago swapped that simple existence for tangible glamour. Among imposing 19th-century villas where grand European families sought out a cool breeze to escape the hot summer lies the much loved Albatroz, a constant in a shifting seascape. Since opening as an inn in the 1960s, it has blossomed to become one of the first five-stars in town. Its buildings jut out on a rocky promontory, close enough for the sound of pounding waves to weave through any pillow talk, with Conceição Beach just steps away. Inside there is an enduring sense of elegance, a hint of mystery from the war era when spies filled the salons. A 21st-century freshness has been added by designer Gracinha Viterbo, who introduced hand-painted tiles, limestone, and palm-tree wallpaper', 'albatroz.jpg'),
('F003', 'Grand Hôtel de Cala Rossa', 'Corsicans get a bad rap for being inhospitable, especially compared to their island neighbors, but there are two sides to life here: the one locals enjoy—access to secret beaches and an enveloping sense of community—and the more polished, arms-length experience that visitors tend to encounter. What’s special about this place, near the glitzy coastal town of Porto-Vecchio, is that it offers both. Run by the Canarelli family since the late 1970s', 'cola.jpg'),
('F004', 'Santa Clara 1728', 'Start us off with an overview.\r\nIt\'s easy to get here from the airport—about 20 minutes. The hotel sits on a square in the old cultural quarter of Lisbon: really beautiful and less gritty and touristy than the Chiado. It’s also close to the monastery São Vicente de Fora. The only downside is that it\'s near where the cruise ships dock, but I never saw any tourists around the hotel.\r\nHow did it strike you on arrival?\r\nIt’s a stunning space—an architect’s dream. There are only six rooms total in an 18th-century building that’s been painstakingly restored (think eggshell blue walls, limestone staircase, giant oil paintings leaning up against the wall). Bonus: The hotel is right on Feira da Ladra, Lisbon’s best flea market that pops up every Tuesday and Saturday.', 'santa.jpg'),
('F005', 'Hotel Astoria, A Rocco Forte Hotel', 'How did it strike you on arrival?\r\nThe facade is deserving of landmark status, seamlessly blending in with the other baroque-style buildings around it. If it weren\'t for the red \'RF\' (for Rocco Forte) emblazoned awnings, you might not even know it was there. From the moment the front doors are opened, expect your stay to be swathed in first-class service that continues to impress day in and out.', 'astoria.jpg'),
('F006', 'Tenuta di Murlo', 'The first thing you notice is the landscape. In every direction there are rolling hills of deep emerald—and almost nothing else. At this labor of love spanning thousands of acres, the great outdoors is the point. Alessio and Carlotta Carabba Tettamanti have spent the past 12 years converting parts of the estate, which has been in Alessio’s family for centuries, into a project celebrating everything that’s glorious about the green heart of Italy. Remarkably intact, the property looks much as it would have before World War II, when the workers who sustained its upkeep began their exodus to towns, leaving behind more than 55 ruins: farmhouses, barns, a water mill, a watchtower or two. The first to be restored was San Savino. ', 'tenuta.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fotofrance`
--

CREATE TABLE `fotofrance` (
  `fotoID` char(4) NOT NULL,
  `fotonama` varchar(60) NOT NULL,
  `fotoket` text NOT NULL,
  `fotofile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fotofrance`
--

INSERT INTO `fotofrance` (`fotoID`, `fotonama`, `fotoket`, `fotofile`) VALUES
('F001', 'Hotel Tivoli', 'Painters and art world royalty Brice and Helen Marden have lived in Tivoli (about two hours north of New York City) for 12 years, and when their local hangout—a restaurant in the Madalin Hotel—was shuttered a couple of years ago, Brice says he was “so depressed at driving by this empty, dead building” that they bought it.', 'hotel tivoli.jpg'),
('F002', 'The Albatroz', 'Although once a whitewashed fishing village, Cascais long ago swapped that simple existence for tangible glamour. Among imposing 19th-century villas where grand European families sought out a cool breeze to escape the hot summer lies the much loved Albatroz, a constant in a shifting seascape. Since opening as an inn in the 1960s, it has blossomed to become one of the first five-stars in town. Its buildings jut out on a rocky promontory, close enough for the sound of pounding waves to weave through any pillow talk, with Conceição Beach just steps away. Inside there is an enduring sense of elegance, a hint of mystery from the war era when spies filled the salons. A 21st-century freshness has been added by designer Gracinha Viterbo, who introduced hand-painted tiles, limestone, and palm-tree wallpaper', 'albatroz.jpg'),
('F003', 'Grand Hôtel de Cala Rossa', 'Corsicans get a bad rap for being inhospitable, especially compared to their island neighbors, but there are two sides to life here: the one locals enjoy—access to secret beaches and an enveloping sense of community—and the more polished, arms-length experience that visitors tend to encounter. What’s special about this place, near the glitzy coastal town of Porto-Vecchio, is that it offers both. Run by the Canarelli family since the late 1970s', 'cola.jpg'),
('F004', 'Santa Clara 1728', 'Start us off with an overview.\r\nIt\'s easy to get here from the airport—about 20 minutes. The hotel sits on a square in the old cultural quarter of Lisbon: really beautiful and less gritty and touristy than the Chiado. It’s also close to the monastery São Vicente de Fora. The only downside is that it\'s near where the cruise ships dock, but I never saw any tourists around the hotel.\r\nHow did it strike you on arrival?\r\nIt’s a stunning space—an architect’s dream. There are only six rooms total in an 18th-century building that’s been painstakingly restored (think eggshell blue walls, limestone staircase, giant oil paintings leaning up against the wall). Bonus: The hotel is right on Feira da Ladra, Lisbon’s best flea market that pops up every Tuesday and Saturday.', 'santa.jpg'),
('F005', 'Hotel Astoria, A Rocco Forte Hotel', 'How did it strike you on arrival?\r\nThe facade is deserving of landmark status, seamlessly blending in with the other baroque-style buildings around it. If it weren\'t for the red \'RF\' (for Rocco Forte) emblazoned awnings, you might not even know it was there. From the moment the front doors are opened, expect your stay to be swathed in first-class service that continues to impress day in and out.', 'astoria.jpg'),
('F006', 'Tenuta di Murlo', 'The first thing you notice is the landscape. In every direction there are rolling hills of deep emerald—and almost nothing else. At this labor of love spanning thousands of acres, the great outdoors is the point. Alessio and Carlotta Carabba Tettamanti have spent the past 12 years converting parts of the estate, which has been in Alessio’s family for centuries, into a project celebrating everything that’s glorious about the green heart of Italy. Remarkably intact, the property looks much as it would have before World War II, when the workers who sustained its upkeep began their exodus to towns, leaving behind more than 55 ruins: farmhouses, barns, a water mill, a watchtower or two. The first to be restored was San Savino. ', 'tenuta.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fotomaldive`
--

CREATE TABLE `fotomaldive` (
  `fotoID` char(4) NOT NULL,
  `fotonama` varchar(60) NOT NULL,
  `fotoket` text NOT NULL,
  `fotofile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fotomaldive`
--

INSERT INTO `fotomaldive` (`fotoID`, `fotonama`, `fotoket`, `fotofile`) VALUES
('F001', 'West Shore', 'With 55 rooms and suites, an outdoor pool, and an award-winning wine list at the onsite bistro, the family- and pet-friendly PlumpJack Squaw Valley Inn reopens this month. It’s steps from Squaw Valley’s world-renowned skiing, while Tahoe City shops and the lake are eight miles away.', '1.jpg'),
('F002', 'Squaw-Alpine', 'The Bavarian-inspired Cobblestone Center houses independently owned businesses such as Tipsy Gipsy for casual women’s clothing, Pineapple for home decor, and Tahoe Trunk Show for a rotation of art, jewelry, and woodwork. Uncorked wine bar offers to-go bottles of limited production wines from appellations around the globe', '3.jpg'),
('F003', 'Northstar', 'The Ritz Carlton’s easy ski-in, ski-out access makes it ideal for those who want to hit the Northstar slopes fast. The hotel’s posh aprés-ski scene pairs Moët & Chandon champagne with music and a raw bar of chilled shrimp cocktail, crab, and caviar by outdoor firepits.', '2.jpg'),
('F004', 'Cuppa', 'Look for souvenirs at Gaialicious, which features local artisans and fair trade imports, including metal and gemstone jewelry from South Lake Tahoe designer Melissa Giselle and ceramics by the husband and wife team at MB Art Studios in Reno.', '4.jpg'),
('F005', 'Memphis, Tennessee', 'Driving is your safest mode of transportation. But even then, says Diego Hijano, a physician and infectious disease expert with St. Jude Children\'s Research Hospital in Memphis, Tennessee, plan your route in advance: “Pack all of your food ahead of time so you don’t have to stop as often and interact with people.”', '5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fototahiti`
--

CREATE TABLE `fototahiti` (
  `fotoID` char(4) NOT NULL,
  `fotonama` varchar(60) NOT NULL,
  `fotoket` text NOT NULL,
  `fotofile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fototahiti`
--

INSERT INTO `fototahiti` (`fotoID`, `fotonama`, `fotoket`, `fotofile`) VALUES
('F001', 'Sleek Confines', 'The hotel is located precisely where the centuries-old Kyoto residence of the Mitsui family—the original founders of a slew of Japanese corporations—once stood. Beneath its five-star sheen and contemporary décor (by creatives including architect Akira Kuryu and Hong Kong–based Andre Fu) the new-build hotel, home to 161 rooms and two restaurants, is firmly rooted in its Kyoto heritage.', '1.jpg'),
('F002', 'Mitsui Estate', 'Arriving after dark, I walk beneath the 18th century Kajiimiya Gate, with its grandly curved roof and solid wood frame (it once marked the entrance to the Mitsui estate), passing pine trees, a stone pagoda and an arc of maples en route to the Fu-designed lobby. Here, beneath a horizontal washi light.', '2.jpg'),
('F003', 'Stepping Stones', 'The hotel wraps around a modern reinterpretation of the family’s original “strolling garden,” by landscape designer Shunsaku Miyagi, with atmospheric lantern-lit water features, a weeping cherry tree, reddening maples, and stepping stones.', '3.jpg'),
('F004', 'Wabi Sabi', 'close-up views of Nijo Castle, is a luxe, modern riff on traditional teahouse aesthetics: light green carpets with abstract water motifs, expanses of pale birch wood, a wabi sabi moss pot, and subtle textile panels by kimono designer Jotaro Saito above the bed.\r\n\r\n', '4.jpg'),
('F005', 'Hoshinoya Ubud', 'Destination spas to dreamy beach hangouts and cliff top architectural wonders—by every big name in the business. So when Japan-based hotel group Hoshino Resorts splashed onto the scene in 2017, it knew it would have to do something different. It couldn’t have picked a more suitable plot, a 25-minute drive from the clutter of Ubud, on a hilltop amid rice fields and dense jungle. Rie Azuma, the architect behind all Hoshinoya properties, blended the simplicity of Japanese styling with local tradition, creating earthy-hued,', '5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fotothailand`
--

CREATE TABLE `fotothailand` (
  `fotoID` char(4) NOT NULL,
  `fotonama` varchar(60) NOT NULL,
  `fotoket` text NOT NULL,
  `fotofile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fotothailand`
--

INSERT INTO `fotothailand` (`fotoID`, `fotonama`, `fotoket`, `fotofile`) VALUES
('F001', 'Sleek Confines', 'The hotel is located precisely where the centuries-old Kyoto residence of the Mitsui family—the original founders of a slew of Japanese corporations—once stood. Beneath its five-star sheen and contemporary décor (by creatives including architect Akira Kuryu and Hong Kong–based Andre Fu) the new-build hotel, home to 161 rooms and two restaurants, is firmly rooted in its Kyoto heritage.', '1.jpg'),
('F002', 'Mitsui Estate', 'Arriving after dark, I walk beneath the 18th century Kajiimiya Gate, with its grandly curved roof and solid wood frame (it once marked the entrance to the Mitsui estate), passing pine trees, a stone pagoda and an arc of maples en route to the Fu-designed lobby. Here, beneath a horizontal washi light.', '2.jpg'),
('F003', 'Stepping Stones', 'The hotel wraps around a modern reinterpretation of the family’s original “strolling garden,” by landscape designer Shunsaku Miyagi, with atmospheric lantern-lit water features, a weeping cherry tree, reddening maples, and stepping stones.', '3.jpg'),
('F004', 'Wabi Sabi', 'close-up views of Nijo Castle, is a luxe, modern riff on traditional teahouse aesthetics: light green carpets with abstract water motifs, expanses of pale birch wood, a wabi sabi moss pot, and subtle textile panels by kimono designer Jotaro Saito above the bed.\r\n\r\n', '4.jpg'),
('F005', 'Hoshinoya Ubud', 'Destination spas to dreamy beach hangouts and cliff top architectural wonders—by every big name in the business. So when Japan-based hotel group Hoshino Resorts splashed onto the scene in 2017, it knew it would have to do something different. It couldn’t have picked a more suitable plot, a 25-minute drive from the clutter of Ubud, on a hilltop amid rice fields and dense jungle. Rie Azuma, the architect behind all Hoshinoya properties, blended the simplicity of Japanese styling with local tradition, creating earthy-hued,', '5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `fototurkey`
--

CREATE TABLE `fototurkey` (
  `fotoID` char(4) NOT NULL,
  `fotonama` varchar(60) NOT NULL,
  `fotoket` text NOT NULL,
  `fotofile` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fototurkey`
--

INSERT INTO `fototurkey` (`fotoID`, `fotonama`, `fotoket`, `fotofile`) VALUES
('F001', 'West Shore', 'With 55 rooms and suites, an outdoor pool, and an award-winning wine list at the onsite bistro, the family- and pet-friendly PlumpJack Squaw Valley Inn reopens this month. It’s steps from Squaw Valley’s world-renowned skiing, while Tahoe City shops and the lake are eight miles away.', '1.jpg'),
('F002', 'Squaw-Alpine', 'The Bavarian-inspired Cobblestone Center houses independently owned businesses such as Tipsy Gipsy for casual women’s clothing, Pineapple for home decor, and Tahoe Trunk Show for a rotation of art, jewelry, and woodwork. Uncorked wine bar offers to-go bottles of limited production wines from appellations around the globe', '3.jpg'),
('F003', 'Northstar', 'The Ritz Carlton’s easy ski-in, ski-out access makes it ideal for those who want to hit the Northstar slopes fast. The hotel’s posh aprés-ski scene pairs Moët & Chandon champagne with music and a raw bar of chilled shrimp cocktail, crab, and caviar by outdoor firepits.', '2.jpg'),
('F004', 'Cuppa', 'Look for souvenirs at Gaialicious, which features local artisans and fair trade imports, including metal and gemstone jewelry from South Lake Tahoe designer Melissa Giselle and ceramics by the husband and wife team at MB Art Studios in Reno.', '4.jpg'),
('F005', 'Memphis, Tennessee', 'Driving is your safest mode of transportation. But even then, says Diego Hijano, a physician and infectious disease expert with St. Jude Children\'s Research Hospital in Memphis, Tennessee, plan your route in advance: “Pack all of your food ahead of time so you don’t have to stop as often and interact with people.”', '5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `hotel`
--

CREATE TABLE `hotel` (
  `HotelID` char(5) NOT NULL,
  `HotelNama` char(35) NOT NULL,
  `HotelAlamat` char(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hotel`
--

INSERT INTO `hotel` (`HotelID`, `HotelNama`, `HotelAlamat`) VALUES
('HOT1', 'Monastero Santa Rosa Hotel & Spa', 'Monastero Santa Rosa Hotel & Spa'),
('HOT2', 'Grand Hotel Tremezzo', 'Lake Como, Italy'),
('HOT3', 'Museum Hotel, Bentonville', 'Bentonville, Arkansas'),
('HOT4', 'The Nautilus, Maldives', 'UNESCO World Biosphere Reserve Baa Atoll');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `kategoriID` char(4) NOT NULL,
  `kategoriNama` char(30) NOT NULL,
  `kategoriketerangan` varchar(255) NOT NULL,
  `kategorireferensi` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`kategoriID`, `kategoriNama`, `kategoriketerangan`, `kategorireferensi`) VALUES
('KAT1', 'Cultures', 'The following outline is provided as an overview of and topical guide to culture.', 'Books'),
('KAT2', 'Cuisine', 'Cuisine involves food preparation in a particular style, of food and drink of particular types.', 'Books'),
('KAT3', 'Photogenic', 'Perfect for photo-ops (though other tourists might get in your shot), and Wildlife Refuge is ideal for vacationers wanting to share .', 'Books'),
('KAT4', 'Adventure', 'Adventure travel may be any tourist activity that includes physical activity, a cultural exchange, and connection with nature.', 'Books'),
('KAT5', 'City', 'Urban tourism is a type of tourism where is located in the large human agglomerations, usually in the main cities of each country.', 'Books'),
('KAT6', 'Honeymoon', 'honeymoon is a holiday taken by newlyweds immediately after their wedding, to celebrated in destinations considered exotic or romantic.', 'Books'),
('WK01', 'Alam', 'Wisata dengan pemandangan pantai dan gunung', 'Buku Sejarah'),
('WK02', 'Budaya', 'Wisata sejarah, peninggalan masa lalu', 'Buku'),
('WK03', 'Taman', 'Disneyland', 'Iklan'),
('WK04', 'Pantai', 'Dekat Laut', 'Pengguna'),
('WK05', 'Perkemahan', 'Dekat bakso mading', 'Teman'),
('WK06', 'Religi', 'Wisata rohani', 'Buku');

-- --------------------------------------------------------

--
-- Table structure for table `provinsi`
--

CREATE TABLE `provinsi` (
  `provinsiID` char(2) NOT NULL,
  `provinsiNama` char(25) NOT NULL,
  `provinsiTglBerdiri` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `provinsi`
--

INSERT INTO `provinsi` (`provinsiID`, `provinsiNama`, `provinsiTglBerdiri`) VALUES
('01', 'California', '2020-11-18'),
('02', 'Connecticut', '2020-11-25'),
('03', 'Massachusetts', '1933-09-09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `area`
--
ALTER TABLE `area`
  ADD PRIMARY KEY (`areaID`);

--
-- Indexes for table `beritawisata`
--
ALTER TABLE `beritawisata`
  ADD PRIMARY KEY (`beritaID`);

--
-- Indexes for table `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`destinasiID`);

--
-- Indexes for table `fotodestinasi`
--
ALTER TABLE `fotodestinasi`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `fotofiji`
--
ALTER TABLE `fotofiji`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `fotofrance`
--
ALTER TABLE `fotofrance`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `fotomaldive`
--
ALTER TABLE `fotomaldive`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `fototahiti`
--
ALTER TABLE `fototahiti`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `fotothailand`
--
ALTER TABLE `fotothailand`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `fototurkey`
--
ALTER TABLE `fototurkey`
  ADD PRIMARY KEY (`fotoID`);

--
-- Indexes for table `hotel`
--
ALTER TABLE `hotel`
  ADD PRIMARY KEY (`HotelID`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`kategoriID`);

--
-- Indexes for table `provinsi`
--
ALTER TABLE `provinsi`
  ADD PRIMARY KEY (`provinsiID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
