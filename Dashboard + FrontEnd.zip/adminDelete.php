<?php
include "includes/config.php";
if (isset($_GET['hapus'])) {
    $adminID = $_GET["hapus"];
    mysqli_query($connection, "DELETE FROM a_travel.admin WHERE adminID = '$adminID'");
    echo "<script>alert('Data berhasil dihapus!');
        document.location='tables.php'</script>";
}
?>