<?php
    include "includes/config.php";
    if (isset($_GET['hapus'])) {
        $destinasiKode = $_GET["hapus"];
        mysqli_query($connection, "DELETE FROM a_travel.destinasi WHERE destinasiID = '$destinasiKode'");
        echo "<script>alert('Data berhasil dihapus!');
document.location='destinasi.php'</script>";
    }
?>