<?php
    include "includes/config.php";
    if (isset($_GET['hapus'])) {
        $areaID = $_GET["hapus"];
        mysqli_query($connection, "DELETE FROM a_travel.area WHERE areaID = '$areaID'");
        echo "<script>alert('Data berhasil dihapus!');
        document.location='area.php'</script>";
    }
?>