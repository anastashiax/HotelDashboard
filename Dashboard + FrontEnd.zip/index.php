<!DOCTYPE html>
<?php
    ob_start();
    session_start();
    if(!isset($_SESSION['emailUser'])) {
        header("location:login.php");
    }
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Database SB - Admin 2</title>
</head>
<body>
<?php include "header.php";?>
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h1 class="display-4">Admin Dashboard</h1>
            <p>Created by Anastasia Aurelia / 825180062</p>
            <h2>Update With The News!  <a href="beritawisata.php"><input type="submit" class="btn btn-primary" value="News!" name="News"></a></h4></h2> 
            <h2> Click Here To Open Main Page...  <a href="PHP_SESI8/index.php"><input type="submit" class="btn btn-primary" value="Main Page" name="Pagination"></a></h4></h2>          
        </div>
    </div>
    <div class="jumbotron jumbotron-fluid">
    <div class="container">
        <h1 class="display-4">Quick Access to All Database!</h1>
        <p>Below are all the Tables prepared by our Dashboard!</p>
        <h4>Table Admin  <a href="tables.php"><input type="submit" class="btn btn-primary" value="Admin table" name="Admin table"></a></h4>
        <h4>Table Hotel  <a href="hotel.php"><input type="submit" class="btn btn-primary" value="Hotel" name="Hotel"></a></h4>
        <h4>Table Destination Category  <a href="inputoutput.php"><input type="submit" class="btn btn-primary" value="Category" name="Category"></a></h4>
        <h4>Table Photography <a href="fotodestinasi.php"><input type="submit" class="btn btn-primary" value="Destination Picture" name="Destination Picture"></a></h4>
        <h4>Table Destination <a href="destinasi.php"><input type="submit" class="btn btn-primary" value="Destination" name="Destination"></a></h4>
        <h4>Table Area  <a href="area.php"><input type="submit" class="btn btn-primary" value="Area" name="Area"></a></h4>
        <h4>Table Province  <a href="Provinsi.php"><input type="submit" class="btn btn-primary" value="Province" name="Province"></a></h4>
    </div>
    </div>
<?php include "footer.php";?>
</body>
<?php
    include "includes/config.php";
    mysqli_close($connection);
    ob_end_flush();
?>
</html>