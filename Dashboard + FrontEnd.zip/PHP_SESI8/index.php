<!doctype html>
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Abril+Fatface&display=swap" rel="stylesheet">
<?php 
    include "include/config.php";
    $query = mysqli_query($connection, "SELECT * FROM area");
    $sql = mysqli_query($connection, "SELECT * FROM a_travel.destinasi");
    $jumlah = mysqli_num_rows($sql);
    $foto = mysqli_query($connection, "SELECT * FROM a_travel.fotodestinasi");
    $jml = mysqli_num_rows($foto);
    $berita = mysqli_query($connection, "SELECT * FROM a_travel.beritawisata");
    $jmlh = mysqli_num_rows($berita);
    $hotel = mysqli_query($connection, "SELECT * FROM a_travel.hotel");
    $jum = mysqli_num_rows($hotel);
    $sum = mysqli_num_rows($query);

    $destinasi = mysqli_query($connection, "SELECT * FROM kategori, destinasi, fotodestinasi WHERE kategori.kategoriID = destinasi.kategoriID AND destinasi.destinasiID = fotodestinasi.destinasiID");

    $sql = mysqli_query($connection, "SELECT * FROM destinasi");
    $jumlah = mysqli_num_rows($sql);

    $foto = mysqli_query($connection, "SELECT * FROM fotodestinasi");

    $query_kat = mysqli_query($connection, "SELECT * FROM kategori");
    $query_des = mysqli_query($connection, "SELECT * FROM provinsi");
    $query_hot = mysqli_query($connection, "SELECT * FROM hotel");
?>

<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>WISATA</title>
  </head>
  <body>
    
<!-- MEMBUAT MENU -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<a class="navbar-brand" href="index.php">
      <img src="images/falconpng.png" style="width: 60px">
    </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Area
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        
        <?php if(mysqli_num_rows($query) > 0) {
          while ($row = mysqli_fetch_array($query))
          { ?>
          <a class="dropdown-item" href="#"><?php echo $row["areaNama"]?></a>
        <?php } } ?>

        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="destinasi.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Destinasi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        
        <?php if(mysqli_num_rows($sql) > 0) {
          while ($row = mysqli_fetch_array($sql))
          { ?>
          <a class="dropdown-item" href="destinasi.php"><?php echo $row["destinasiNama"]?></a>
        <?php } } ?>

        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="fotodestinasi.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Foto Destinasi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        
        <?php if(mysqli_num_rows($foto) > 0) {
          while ($row = mysqli_fetch_array($foto))
          { ?>
          <a class="dropdown-item" href="#"><?php echo $row["fotoNama"]?></a>
        <?php } } ?>

        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="hotel.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Hotel Destinasi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        
        <?php if(mysqli_num_rows($hotel) > 0) {
          while ($row = mysqli_fetch_array($hotel))
          { ?>
          <a class="dropdown-item" href="Hotel.php"><?php echo $row["HotelNama"]?></a>
        <?php } } ?>

        </div>
      </li>


      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="berita.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Berita Destinasi
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        
        <?php if(mysqli_num_rows($berita) > 0) {
          while ($row = mysqli_fetch_array($berita))
          { ?>
          <a class="dropdown-item" href="beritawisata.php"><?php echo $row["beritaID"]?></a>
        <?php } } ?>

        </div>
      </li>

      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="berita.php" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Pagination Gallery
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="fiji.php">Fiji</a>
            <a class="dropdown-item" href="maldives.php">Maldives</a>
            <a class="dropdown-item" href="tahiti.php">Tahiti</a>
            <a class="dropdown-item" href="france.php">France</a>
            <a class="dropdown-item" href="turkey.php">Turkey</a>
            <a class="dropdown-item" href="thailand.php">Thailand</a>
        </div>

      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
<!-- AKHIR MENU -->

<!-- SLIDER -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/3.jpg" alt="First slide" width="500" height="600">
      <div class="carousel-caption d-none d-md-block">
            <h1 style= "font-family: 'Abril Fatface', cursive">Experience Yellowstone National Park</h1>
            <p>Yellowstone National Park has made great strides on sustainability in recent years. </p>
      </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/2.jpg" alt="Second slide" width="500" height="600">
      <div class="carousel-caption d-none d-md-block">
            <h1 style= "font-family: 'Abril Fatface', cursive">Sustainable tourism and Indigenous culture thrive in Australia</h1>
            <p>A big splash in the world of conservation with Limmen Bight Marine Park. </p>
      </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/4.jpg" alt="Third slide" width="500" height="600">
      <div class="carousel-caption d-none d-md-block">
            <h1 style= "font-family: 'Abril Fatface', cursive">Future of urban life around the world</h1>
            <p>The city once called New Amsterdam is doing like the Dutch once more by opting for solar-powered. </p>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<!-- AKHIR SLIDER -->
<br><br>

<!-- MEMBUAT TAMPILAN OBJEK -->
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
            <?php if(mysqli_num_rows($destinasi) > 0) {
                while ($row2 = mysqli_fetch_array($destinasi)) { ?>
                <div class="media">
                    <div class="media-body">
                        <h4 style= "font-family: 'Abril Fatface', cursive" class="mt-0 mb-1"><?php echo $row2['destinasiNama'] ?></h4>
                        <h5 style= "font-family: 'Abril Fatface', cursive"><?php echo $row2['destinasiAlamat'] ?></h5>
                        <p><?php echo $row2['kategoriketerangan'] ?></p>
                        <br>
                    </div>
                    <img class="ml-3" style="width: 200px; height: 100%" src="images/<?php echo $row2['fotoFile'] ?>" alt="Gambar Tidak Ada">
                </div>
            <?php } } ?>


            </div>
            <div class="col-sm-4">
        <ul class="list-group">
          <li class="list-group-item d-flex justify-content-between align-items-center">
            Jumlah Destinasi Wisata
          <span class="badge badge-primary badge-pill"><?php echo $jumlah?></span>
          </li>

          <li class="list-group-item d-flex justify-content-between align-items-center">
            Jumlah Foto Wisata
          <span class="badge badge-primary badge-pill"><?php echo $jml?></span>
          </li>

          <li class="list-group-item d-flex justify-content-between align-items-center">
            Jumlah Berita Wisata
            <span class="badge badge-primary badge-pill"><?php echo $jmlh?></span>
          </li>

          <li class="list-group-item d-flex justify-content-between align-items-center">
            Jumlah Hotel Wisata
            <span class="badge badge-primary badge-pill"><?php echo $jum?></span>
          </li>

          <li class="list-group-item d-flex justify-content-between align-items-center">
            Jumlah Area Wisata
            <span class="badge badge-primary badge-pill"><?php echo $sum?></span>
          </li>
        </ul>
      </div>
    </div>
  </div>   
<!-- END OBJEK -->
<!-- GALERI -->
<div class="container">
<div class="row">

<?php while ($row3 = mysqli_fetch_array($foto)) { ?>
<div class="col-sm-4">
<figure class="figure">
  <img src="images/<?php echo $row3['fotoFile'] ?>" class="figure-img img-fluid rounded" alt="Foto Tidak Ada">
  <figcaption class="figure-caption text-right"><?php echo $row3['fotoNama'] ?></figcaption>
</figure>
</div>
<?php } ?>
</div>
</div>

<!-- END GALERI -->
<style>
.testimonial {
    background: #f7f7f7;
}

.testimonial .content {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
}

.testimonial .content .testimonialBox {
    max-width: calc(40% - 30px);
    padding: 60px 40px;
    margin: 20px;
    background : red;
}

.testimonial .content .testimonialBox p {
    color :#fff;
    font-style: italic;
    font-size: 16px;
    font-weight: 2;
}

.testimonial .content .testimonialBox h3 {
    margin-top: 40px;
    text-align: end;
    color: #fff;
    font-weight: 600;
    font-size: 20px;
    line-height: 1em;
}

.testimonial .content .testimonialBox h3 span {
    font-size: 14px;
    font-weight: 400;
}</style>
<div class="jumbotron jumbotron-fluid text-center">
      <div class="container">
        <section class="testimonial" id="testimonial">
        <div class="heading">
        <h1 style= "font-family: 'Abril Fatface', cursive">Reviews</h1>
    
        </div>
        <div class="content">
            <div class="testimonialBox">
                <p>Everything was absolutely amazing! The villa, staff, surroundings. We extend our stay for another 3 weeks. Thank you very much for your great and professional service! I really enjoy outside bath, delicious breakfast, quiet and privacy in own pool.
                </p>
                <h3>Anastasia Aurelia<br><span>Royal School Of Music. London, UK</span></h3>
            </div>
            <div class="testimonialBox">
                <p>
                The room and view was very nice. We love the sound environment and also the breakfast was amazing!
                </p>
                <h3>Daniela Drache<br><span>Stanford University. California</span></h3>
            </div>
            <div class="testimonialBox">
                <p>
                Absolutely amazing accomodations!! The best breakfast of any place we stayed during our vacation. Joe and Christopher are fantastic hosts. Will definitely stay here when we return to Nova Scotia!
                </p>
                <h3>Joan Kennedy<br><span>Harvard University. Cambridge, Massachusetts.</span></h3>
            </div>
            <div class="testimonialBox">
                <p>
                Very warm welcome from the owners, the house and the room we got were beautiful and clean. The house is located on top of a hill, the view in the morning is amazing! The breakfast was great with fresh ingredients.
                </p>
                <h3>Thamara Hoefkens, Ph.D<br><span>Massachusetts Institute of Technology. Cambridge</span></h3>
            </div>
        </div>
    </section>        <br>
        <a class="btn btn-danger btn-lg" target="_blank" href="/adminanas/test2/index.html" role="button" >MORE</a>
      </div>
  </div>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script> -->
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>
  </body>
</html>