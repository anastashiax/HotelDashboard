<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wisata</title>
</head>

<?php
    ob_start();
    session_start();
    if(!isset($_SESSION['emailUser'])) {
        header("location:login.php");
    }
?>

<?php include "header.php";?>

<div class="container-fluid">
    <div class="card shadow mb-4">

<?php
    include "includes/config.php";

    if(isset($_POST['Save'])) {
        if (isset($_REQUEST['inputDestinasiID'])) {
            $destinasiKode = $_REQUEST['inputDestinasiID'];
        }

        if (!empty($destinasiKode)) {
            $destinasiKode = $_REQUEST ['inputDestinasiID'];
        }
        
        else {
            die ("Anda harus memasukkan Kodenya");
        }

        $destinasiNama = $_POST['inputDestinasiNama'];
        $destinasiAlamat = $_POST['inputDestinasiAlamat'];
        $kodeKategori = $_POST['kodeKategori'];
        $kodeArea = $_POST['kodeArea'];

        mysqli_query(($connection), "Insert into a_travel.Destinasi values ('$destinasiKode', '$destinasiNama', '$destinasiAlamat', '$kodeKategori', '$kodeArea')");

        header("location:destinasi.php");
    }

    $dataKategori = mysqli_query($connection, "SELECT * FROM a_travel.kategori");
    $dataArea = mysqli_query($connection, "SELECT * FROM a_travel.area");
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Wisata</title>
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
    <div class="row">
    <div class="col-sm-1">
    </div>

    <div class="col-sm-10">
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <h1 class="display-4">Input Wisata</h1>
                <h2>Please Insert Your Data Here..</h2>
            </div>
        </div> <!-- penutup jumbtron -->

    <form method="POST">
        <div class="form-group row">
            <label for="destinasiID" class="col-sm-2 col-form-label">Kode Destinasi</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="destinasiID" name="inputDestinasiID" placeholder="Kode Destinasi (max. 5 characters)" maxlength="5">
        </div>
        </div>

        <div class="form-group row">
            <label for="destinasiNama" class="col-sm-2 col-form-label">Nama Destinasi</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="destinasiNama" name="inputDestinasiNama" placeholder="Nama Destinasi (max. 35 characters)" maxlength="35">
        </div>
        </div>

        <div class="form-group row">
            <label for="destinasiAlamat" class="col-sm-2 col-form-label">Alamat Destinasi</label>
        <div class="col-sm-10">
            <input type="text" class="form-control" id="destinasiAlamat" name="inputDestinasiAlamat" placeholder="Alamat Destinasi (max. 255 characters)" maxlength="255">
        </div>
        </div>

        <div class="form-group row">
            <label for="areaKeterangan" class="col-sm-2 col-form-label">Kategori Wisata</label>
            <div class="col-sm-10">
            <select class="form-control" id="kodeKategori" name="kodeKategori">
                    <?php 
                        while($row = mysqli_fetch_array($dataKategori)) {
                    ?>
                <option value="<?php echo $row["kategoriID"]?>">
                    <?php echo $row["kategoriID"]?>
                    <?php echo $row["kategoriNama"]?>
                </option>
                    <?php } ?>
            </select>
            </div>
        </div>

        <div class="form-group row">
            <label for="areaKeterangan" class="col-sm-2 col-form-label">Area Wisata</label>
            <div class="col-sm-10">
            <select class="form-control" id="kodeArea" name="kodeArea">
                    <?php 
                        while($row = mysqli_fetch_array($dataArea)) {
                    ?>
                <option value="<?php echo $row["areaID"] ?>">
                    <?php echo $row["areaID"]?>
                    <?php echo $row["areaNama"]?>
                </option>
                    <?php } ?>
            </select>
            </div>
        </div>

        <div class="form-group row">
            <div class="col-sm-2"></label>
        </div>
            <div class="col-sm-10">
                <input type="submit" class="btn btn-primary" value="Save" name="Save">
                <input type="reset" class="btn btn-secondary" value="Cancel" name="'Cancel">
            </div>
        </div>
    </form>
</div>

<div class="col-sm-1">
</div>
</div> 

<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <h1 class="display-4">Table Destinasi Wisata</h1>
                <h2>All Your Data Will Be Shown Here..</h2>
            </div>

        </div> <!-- penutup jumbtron -->
        <form method="POST">
        <div class="form-group row mb-2">
            <label for="search" class="col-sm-3">Pencarian Nama Destinasi</label>
            <div class="col-sm-6">
                <input type="text" name="search" class="form-control" id="search" value="<?php if(isset($_POST['search'])) {echo $_POST['search'];}?>" placeholder="Cari Nama Destinasi">
            </div>
            <input type="submit" name="kirim" class="col-sm-1 btn btn-primary" value="Search">
        </div>
    </form>

    <table class="table table-hover table-danger">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Kode</th>
                <th>Nama Destinasi Wisata</th>
                <th>Alamat Destinasi Wisata</th>
                <th>Kode Kategori</th>
                <th>Nama Kategori</th>
                <th>Kode Area</th>
                <th>Nama Area</th>
                <th colspan="2" style="text-align: center">Action</th>
            </tr>
        </thead>

        <tbody>
            <?php
            $jumlahtampilan = 3;
            $halaman = (isset($_GET['page']))? $_GET['page'] : 1;
            $mulaitampilan = ($halaman - 1) * $jumlahtampilan;
                if (isset($_POST["kirim"])) {
                    $search = $_POST['search'];
                    $query = mysqli_query($connection, 
                    "select a_travel.Destinasi.*, a_travel.kategori.kategoriID, a_travel.kategori.kategoriNama, a_travel.area.areaID, a_travel.area.areaNama 
                    from a_travel.Destinasi, a_travel.Kategori, a_travel.Area
                    where destinasiNama like '%".$search."%'
                    and Destinasi.kategoriID = Kategori.kategoriID
                    and Destinasi.areaID = Area.areaID limit $mulaitampilan, $jumlahtampilan");
                }
                else {
                $query = mysqli_query($connection, "select a_travel.Destinasi.*, a_travel.Kategori.kategoriID, a_travel.Kategori.kategoriNama, a_travel.Area.areaID, Area.areaNama 
                from a_travel.Destinasi, a_travel.Kategori, a_travel.Area
                where Destinasi.kategoriID = Kategori.kategoriID
                and destinasi.areaID = area.areaID limit $mulaitampilan, $jumlahtampilan");

                }
                $nomor =1;
                while ($row = mysqli_fetch_array($query)) {
                    ?>
                        <tr>
                            <td><?php echo $nomor;?></td>
                            <td><?php echo $row['destinasiID'];?></td>
                            <td><?php echo $row['destinasiNama'];?></td>
                            <td><?php echo $row['destinasiAlamat'];?></td>
                            <td><?php echo $row['kategoriID'];?></td>
                            <td><?php echo $row['kategoriNama'];?></td>
                            <td><?php echo $row['areaID'];?></td>
                            <td><?php echo $row['areaNama'];?></td>
                            <!-- Untuk icon Edit dan Delete -->
                            <td>
                                <a href="destinasiEdit.php?ubah=<?php echo $row["destinasiID"]?>"
                                class="btn btn-success btn-sm" title="Edit Data">
                                <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                </svg>
                                </a>
                            </td>
                            <td>
                                <a href="destinasiHapus.php?hapus=<?php echo $row["destinasiID"]?>"
                                   class="btn btn-danger btn-sm" title="Delete Data">
                                <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash2-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M2.037 3.225l1.684 10.104A2 2 0 0 0 5.694 15h4.612a2 2 0 0 0 1.973-1.671l1.684-10.104C13.627 4.224 11.085 5 8 5c-3.086 0-5.627-.776-5.963-1.775z"/>
                                    <path fill-rule="evenodd" d="M12.9 3c-.18-.14-.497-.307-.974-.466C10.967 2.214 9.58 2 8 2s-2.968.215-3.926.534c-.477.16-.795.327-.975.466.18.14.498.307.975.466C5.032 3.786 6.42 4 8 4s2.967-.215 3.926-.534c.477-.16.795-.327.975-.466zM8 5c3.314 0 6-.895 6-2s-2.686-2-6-2-6 .895-6 2 2.686 2 6 2z"/>
                                </svg>
                                </a>
                            </td>
                            <!-- Akhir icon Edit dan Delete -->
                        </tr>
                    <?php $nomor = $nomor + 1;?>
                <?php }
            ?>
        </tbody>
    </table>

    <?php 
            $query = mysqli_query($connection, "SELECT * FROM destinasi");
            $jumlahrecord = mysqli_num_rows($query);
            $jumlahpage = ceil($jumlahrecord/$jumlahtampilan);
    ?>

<nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item"><a class="page-link" href="?page=<?php $nomorhal=1; echo $nomorhal ?>">First</a></li>
                <?php for($nomorhal = 1; $nomorhal<=$jumlahpage; $nomorhal++)
                { ?>
                <li class="page-item">
                    <?php
                    if($nomorhal!=$halaman)
                    { ?>
                    <a class="page-link" href="?page=<?php echo $nomorhal ?>"><?php echo $nomorhal ?></a>
                    <?php }
                    else { ?>
                    <a class="page-link" href="?page=<?php echo $nomorhal ?>"><?php echo $nomorhal ?></a>
                    <?php } ?>
                </li>
                <?php } ?>
                <li class="page-item"><a class="page-link" href="?page=<?php echo $nomorhal-1 ?>">Last</a></li>
            </ul>
            </nav>

    </div>
    </div>
    <div class="col-sm-1"></div>
</div>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#kodeKategori').select2( {
            allowClear: true,
            placeholder: "Pilih Kategori Wisata"
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#kodeArea').select2( {
            allowClear: true,
            placeholder: "Pilih Area Wisata"
        });
    });
</script>
</div>
<?php include "footer.php";?>
<?php
    mysqli_close($connection);
    ob_end_flush();
?>
</html>