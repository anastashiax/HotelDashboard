<!DOCTYPE html>
<?php
    ob_start();
    session_start();
    if(!isset($_SESSION['emailUser'])) {
        header("location:login.php");
    }
?>

<?php include "header.php";?>

<div class="container-fluid">
    <div class="card shadow mb-4">

        <?php
        include "includes/config.php";

        if(isset($_POST['Save'])) {
            if (isset($_REQUEST['inputProvinsiID'])) {
                $provinsiID = $_REQUEST['inputProvinsiID'];
            }

            if (!empty($provinsiID)) {
                $provinsiID = $_REQUEST ['inputProvinsiID'];
            }

            else {
                ?> <h1>Anda harus mengisi data</h1> <?php
                die ("Anda harus memsukkan datanya");
            }

            $provinsiNama = $_POST['inputProvinsiNama'];
            $provinsiTglBerdiri = $_POST['inputProvinsiTglBerdiri'];

            mysqli_query(($connection), "Insert into a_travel.provinsi values ('$provinsiID', '$provinsiNama', '$provinsiTglBerdiri')");

            header("location:provinsi.php");
        }
        $dataProvinsi = mysqli_query($connection, "SELECT * FROM a_travel.provinsi");

        ?>

        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Database Area</title>
            <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
        </head>
        <div class="row">
            <div class="col-sm-1">
            </div>

            <div class="col-sm-10">
                <div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1 class="display-4">Input Province</h1>
                        <h2>Please Insert Your Data Here..</h2>
                    </div>
                </div> <!-- penutup jumbtron -->

                <form method="POST">
                    <div class="form-group row">
                        <label for="provinsiID" class="col-sm-2 col-form-label">Provinsi ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="provinsiID" name="inputProvinsiID" placeholder="Provinsi ID (max. 2 characters)" maxlength="2">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="provinsiNama" class="col-sm-2 col-form-label">Provinsi Area</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="provinsiNama" name="inputProvinsiNama" placeholder="Provinsi Area (max. 25 characters)" maxlength="25">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="provinsiTglBerdiri" class="col-sm-2 col-form-label">Tanggal Berdiri</label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" id="provinsiTglBerdiri" name="inputProvinsiTglBerdiri" placeholder="Tanggal Berdiri (max. 35 characters)" maxlength="35">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-2"></label>
                        </div>
                        <div class="col-sm-10">
                            <input type="submit" class="btn btn-primary" value="Save" name="Save">
                            <input type="reset" class="btn btn-secondary" value="Cancel" name="'Cancel">
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-sm-1">
            </div>
        </div>

        <div class="row">
            <div class="col-sm-1"></div>
            <div class="col-sm-10">
                <div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1 class="display-4">Table Province</h1>
                        <h2>All Your Data Will Be Shown Here..</h2>
                    </div>

                </div> <!-- penutup jumbtron -->
                <form method="POST">
                    <div class="form-group row mb-2">
                        <label for="search" class="col-sm-3">Pencarian Area</label>
                        <div class="col-sm-6">
                            <input type="text" name="search" class="form-control" id="search" value="<?php if(isset($_POST['search'])) {echo $_POST['search'];}?>" placeholder="Cari ID/Nama/Provinsi ID">
                        </div>
                        <input type="submit" name="kirim" class="col-sm-1 btn btn-primary" value="Search">
                    </div>
                </form>

                <table class="table table-hover table-danger">
                    <thead class="thead-dark">
                    <tr>
                        <th>No.</th>
                        <th>Provinsi ID</th>
                        <th>Nama Provinsi</th>
                        <th>Tanggal Berdiri Provinsi</th>
                        <th colspan="2" style="text-align: center">Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php
                     $jumlahtampilan = 3;
                     $halaman = (isset($_GET['page']))? $_GET['page'] : 1;
                     $mulaitampilan = ($halaman - 1) * $jumlahtampilan;

                    if (isset($_POST["kirim"])) {
                        $search = $_POST['search'];
                        $query = mysqli_query($connection, "select * from a_travel.Provinsi
                    where provinsiID like '%".$search."%'
                        or provinsiNama like '%".$search."%'
                        or provinsiTglBerdiri like '%".$search."%' limit $mulaitampilan, $jumlahtampilan");
                    }
                    else {
                        $query = mysqli_query($connection, "select * from a_travel.Provinsi limit $mulaitampilan, $jumlahtampilan");
                    }
                    $nomor =1;
                    while ($row = mysqli_fetch_array($query)) {
                        ?>
                        <tr>
                            <td><?php echo $nomor;?></td>
                            <td><?php echo $row['provinsiID'];?></td>
                            <td><?php echo $row['provinsiNama'];?></td>
                            <td><?php echo $row['provinsiTglBerdiri'];?></td>
                            <!-- Untuk icon Edit dan Delete -->
                            <td>
                                <a href="provinsiEdit.php?ubah=<?php echo $row["provinsiID"]?>"
                                   class="btn btn-success btn-sm" title="Edit Data">
                                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                    </svg>
                                </a>
                            </td>
                            <td>
                                <a href="provinsiHapus.php?hapus=<?php echo $row["provinsiID"]?>"
                                   class="btn btn-danger btn-sm" title="Delete Data">
                                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash2-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.037 3.225l1.684 10.104A2 2 0 0 0 5.694 15h4.612a2 2 0 0 0 1.973-1.671l1.684-10.104C13.627 4.224 11.085 5 8 5c-3.086 0-5.627-.776-5.963-1.775z"/>
                                        <path fill-rule="evenodd" d="M12.9 3c-.18-.14-.497-.307-.974-.466C10.967 2.214 9.58 2 8 2s-2.968.215-3.926.534c-.477.16-.795.327-.975.466.18.14.498.307.975.466C5.032 3.786 6.42 4 8 4s2.967-.215 3.926-.534c.477-.16.795-.327.975-.466zM8 5c3.314 0 6-.895 6-2s-2.686-2-6-2-6 .895-6 2 2.686 2 6 2z"/>
                                    </svg>
                                </a>
                            </td>
                            <!-- Akhir icon Edit dan Delete -->

                        </tr>
                        <?php $nomor = $nomor + 1;?>
                    <?php }
                    ?>
                    </tbody>
                </table>
                <?php 
                    $query = mysqli_query($connection, "SELECT * FROM destinasi");
                    $jumlahrecord = mysqli_num_rows($query);
                    $jumlahpage = ceil($jumlahrecord/$jumlahtampilan);
            ?>

        <nav aria-label="Page navigation example">
                    <ul class="pagination">
                        <li class="page-item"><a class="page-link" href="?page=<?php $nomorhal=1; echo $nomorhal ?>">First</a></li>
                        <?php for($nomorhal = 1; $nomorhal<=$jumlahpage; $nomorhal++)
                        { ?>
                        <li class="page-item">
                            <?php
                            if($nomorhal!=$halaman)
                            { ?>
                            <a class="page-link" href="?page=<?php echo $nomorhal ?>"><?php echo $nomorhal ?></a>
                            <?php }
                            else { ?>
                            <a class="page-link" href="?page=<?php echo $nomorhal ?>"><?php echo $nomorhal ?></a>
                            <?php } ?>
                        </li>
                        <?php } ?>
                        <li class="page-item"><a class="page-link" href="?page=<?php echo $nomorhal-1 ?>">Last</a></li>
                    </ul>
                    </nav>
            </div>
        </div>
        <div class="col-sm-1"></div>
    </div>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <div class="col-sm-1"></div>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#kodeProvinsi').select2( {
                allowClear: true,
                placeholder: "Pilih Provinsi ID"
            });
        });
    </script>
</div>
<?php include "footer.php";?>
<?php
mysqli_close($connection);
ob_end_flush();
?>
</html>