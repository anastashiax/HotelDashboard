<?php
include "includes/config.php";
if (isset($_GET['hapus'])) {
    $HotelID = $_GET["hapus"];
    mysqli_query($connection, "DELETE FROM a_wisata.Hotel WHERE HotelID = '$HotelID'");
    echo "<script>alert('Data berhasil dihapus!');
        document.location='Hotel.php'</script>";
}
?>