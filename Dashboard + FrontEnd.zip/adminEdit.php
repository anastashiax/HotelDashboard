<!DOCTYPE html>
<?php
    ob_start();
    session_start();
    if(!isset($_SESSION['emailUser'])) {
        header("location:login.php");
    }
?>

<?php include "header.php";?>

<div class="container-fluid">
    <div class="card shadow mb-4">

        <?php
        include "includes/config.php";

        if(isset($_POST['Edit'])) {
            $idAdmin = $_POST['inputAdminID'];
            $namaAdmin = $_POST['inputAdminNama'];
            $emailAdmin = $_POST['inputAdminEmail'];
            $passwordAdmin = MD5($_POST['inputAdminPassword']);

            mysqli_query($connection, "Update a_wisata.admin set adminNama = '$namaAdmin', adminEmail = '$emailAdmin', adminPassword = '$passwordAdmin' WHERE adminID = '$idAdmin'");
            header("location:tables.php");
        }

        // Untuk menampilkan data pada Form Edit
        $adminKode = $_GET["ubah"];
        $adminEdit = mysqli_query($connection, "SELECT * FROM a_travel.admin WHERE adminID = '$adminKode'");
        $rowEdit = mysqli_fetch_array($adminEdit);
        ?>

        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Database Wisata</title>
            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
            <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        </head>

        <div class="row">
            <div class="col-sm-1">
            </div>

            <div class="col-sm-10">
                <div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1 class="display-4">Edit Admin</h1>
                    </div>
                </div> <!-- penutup jumbtron -->

                <form method="POST">
                    <div class="form-group row">
                        <label for="adminID" class="col-sm-2 col-form-label">Admin ID</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="adminID" name="inputAdminID" value ="<?php echo $rowEdit["adminID"]?>" maxlength="5" readonly="readonly">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="adminNama" class="col-sm-2 col-form-label">Nama Admin</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="adminNama" name="inputAdminNama" value ="<?php echo $rowEdit["adminNama"]?>" maxlength="35" readonly="readonly">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="adminEmail" class="col-sm-2 col-form-label">Email Admin</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="adminEmail" name="inputAdminEmail" value ="<?php echo $rowEdit["adminEmail"]?>" maxlength="255">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="adminPassword" class="col-sm-2 col-form-label">Password</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="adminPassword" name="inputAdminPassword" maxlength="255">
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-2">
                        </div>
                        <div class="col-sm-10">
                            <input type="submit" class="btn btn-primary" value="Edit" name="Edit">
                            <input type="reset" class="btn btn-secondary" value="Cancel" name="'Cancel">
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-sm-1">
            </div>
        </div>

        <div class="row">
            <div class="col-sm-1">
            </div>

            <div class="col-sm-10">
                <div class="jumbotron jumbotron-fluid">
                    <div class="container">
                        <h1 class="display-4">Tabel Admin</h1>
                        <h2>Database Admin</h2>
                    </div>
                </div> <!-- penutup jumbtron -->

                <table class="table table-hover table-primary">
                    <thead class="thead-dark">
                    <tr>
                        <th>No</th>
                        <th>Kode Admin</th>
                        <th>Nama Admin</th>
                        <th>Email Admin</th>
                        <th>Password (in MD5)</th>
                        <th colspan="2" style="text-align: center">Action</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php
                    if (isset($_POST["kirim"])) {
                        $search = $_POST['search'];
                        $query = mysqli_query($connection,
                            "SELECT * FROM a_travel.admin");
                    }
                    else {
                        $query = mysqli_query($connection, "SELECT * FROM a_travel.admin");
                    }
                    $nomor =1;
                    while ($row = mysqli_fetch_array($query)) {
                        ?>
                        <tr>
                            <td><?php echo $nomor;?></td>
                            <td><?php echo $row['adminID'];?></td>
                            <td><?php echo $row['adminNama'];?></td>
                            <td><?php echo $row['adminEmail'];?></td>
                            <td><?php echo $row['adminPassword'];?></td>
                            <!-- Untuk icon Edit dan Delete -->
                            <td>
                                <a href="adminEdit.php?ubah=<?php echo $row["adminID"]?>"
                                   class="btn btn-success btn-sm" title="Edit Data">
                                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-pencil-square" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                                        <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                                    </svg>
                                </a>
                            </td>
                            <td>
                                <a href="adminDelete.php?hapus=<?php echo $row["adminID"]?>"
                                   class="btn btn-danger btn-sm" title="Delete Data">
                                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-trash2-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.037 3.225l1.684 10.104A2 2 0 0 0 5.694 15h4.612a2 2 0 0 0 1.973-1.671l1.684-10.104C13.627 4.224 11.085 5 8 5c-3.086 0-5.627-.776-5.963-1.775z"/>
                                        <path fill-rule="evenodd" d="M12.9 3c-.18-.14-.497-.307-.974-.466C10.967 2.214 9.58 2 8 2s-2.968.215-3.926.534c-.477.16-.795.327-.975.466.18.14.498.307.975.466C5.032 3.786 6.42 4 8 4s2.967-.215 3.926-.534c.477-.16.795-.327.975-.466zM8 5c3.314 0 6-.895 6-2s-2.686-2-6-2-6 .895-6 2 2.686 2 6 2z"/>
                                    </svg>
                                </a>
                            </td>
                            <!-- Akhir icon Edit dan Delete -->
                        </tr>
                        <?php $nomor = $nomor + 1;?>
                    <?php }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-sm-1"></div>
    </div>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
</div>
<?php include "footer.php";?>
<?php
mysqli_close($connection);
ob_end_flush();
?>
</html>